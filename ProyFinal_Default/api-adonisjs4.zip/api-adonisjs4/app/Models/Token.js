'use strict'

const Model = use('Model')

class Token extends Model {
}

module.exports = Token
